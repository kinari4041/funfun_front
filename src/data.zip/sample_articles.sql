-- 펀딩 게시글 내용 테이블에 50개의 샘플 데이터 삽입

-- 샘플 1
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    1,
    '식품: 프리미엄 냉동식품 패키지 - 당신의 겨울을 따뜻하게',
    '<h1>프리미엄 냉동식품 패키지</h1><p>이 패키지는 고급 냉동식품을 엄선하여 구성한 특별한 패키지입니다. 식사는 물론 간식까지 다양하게 준비되어 있습니다!</p><p>저희의 후원을 통해 이 멋진 패키지를 집으로 직접 배송받으세요!</p><img src="https://example.com/image1.jpg" alt="냉동식품 패키지 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>10,000원 후원: 냉동식품 1종</li><li>20,000원 후원: 냉동식품 3종</li><li>50,000원 후원: 냉동식품 7종 + 스페셜 선물</li></ul>',
    10000, '냉동식품 1종',
    20000, '냉동식품 3종',
    50000, '냉동식품 7종 + 스페셜 선물',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 2
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    2,
    '커피: 최상급 콜드브루 6병 세트 - 커피 애호가를 위한 필수 아이템',
    '<h1>최상급 콜드브루 6병 세트</h1><p>세계 최고의 콜드브루 커피를 집에서 간편하게 즐기세요! 이 세트는 커피 애호가들이 꿈꾸는 완벽한 패키지입니다.</p><p>후원을 통해 이 훌륭한 커피 세트를 손쉽게 받을 수 있습니다!</p><img src="https://example.com/image2.jpg" alt="콜드브루 세트 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>15,000원 후원: 콜드브루 1병</li><li>30,000원 후원: 콜드브루 3병</li><li>60,000원 후원: 콜드브루 6병 + 추가 선물</li></ul>',
    15000, '콜드브루 1병',
    30000, '콜드브루 3병',
    60000, '콜드브루 6병 + 추가 선물',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 3
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    3,
    '향초: 수제 캔들 컬렉션 - 집안을 밝히는 아름다운 향기',
    '<h1>수제 캔들 컬렉션</h1><p>우아한 디자인과 은은한 향기를 가진 수제 캔들 컬렉션을 소개합니다. 집안을 아늑하게 만들어줄 캔들입니다!</p><p>후원으로 이 특별한 캔들을 집에서 직접 경험하세요!</p><img src="https://example.com/image3.jpg" alt="캔들 컬렉션 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>20,000원 후원: 캔들 1종</li><li>40,000원 후원: 캔들 3종</li><li>70,000원 후원: 캔들 6종 + 향기 증강제</li></ul>',
    20000, '캔들 1종',
    40000, '캔들 3종',
    70000, '캔들 6종 + 향기 증강제',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 4
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    4,
    '헬스케어: 프리미엄 영양제 세트 - 건강을 지키는 첫걸음',
    '<h1>프리미엄 영양제 세트</h1><p>각종 영양소가 풍부한 프리미엄 영양제 세트를 소개합니다. 건강한 라이프스타일을 위한 필수 아이템입니다!</p><p>후원으로 건강을 챙기세요!</p><img src="https://example.com/image4.jpg" alt="영양제 세트 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>25,000원 후원: 영양제 1종</li><li>50,000원 후원: 영양제 3종</li><li>80,000원 후원: 영양제 6종 + 건강 상담 쿠폰</li></ul>',
    25000, '영양제 1종',
    50000, '영양제 3종',
    80000, '영양제 6종 + 건강 상담 쿠폰',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 5
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    5,
    '디지털미디어: 최신 음악 앨범 컬렉션 - 귀를 즐겁게',
    '<h1>최신 음악 앨범 컬렉션</h1><p>최신 음악 앨범들을 모은 컬렉션을 소개합니다. 다양한 장르의 음악을 집에서 편안하게 감상하세요!</p><p>후원으로 음악의 세계에 빠져보세요!</p><img src="https://example.com/image5.jpg" alt="음악 앨범 컬렉션 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>10,000원 후원: 음악 앨범 1장</li><li>20,000원 후원: 음악 앨범 3장</li><li>50,000원 후원: 음악 앨범 6장 + 특별 기념품</li></ul>',
    10000, '음악 앨범 1장',
    20000, '음악 앨범 3장',
    50000, '음악 앨범 6장 + 특별 기념품',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 6
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    6,
    '홈리빙: 스마트 주방 기기 - 주방의 혁신',
    '<h1>스마트 주방 기기</h1><p>최신 기술이 적용된 스마트 주방 기기로 요리를 더욱 간편하게!</p><p>후원으로 주방의 혁신을 경험하세요!</p><img src="https://example.com/image6.jpg" alt="스마트 주방 기기 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>30,000원 후원: 스마트 기기 1종</li><li>60,000원 후원: 스마트 기기 2종</li><li>100,000원 후원: 스마트 기기 3종 + 주방 용품 세트</li></ul>',
    30000, '스마트 기기 1종',
    60000, '스마트 기기 2종',
    100000, '스마트 기기 3종 + 주방 용품 세트',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 7
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    7,
    '패션: 여름에 어울리는 여름 의류 - 시원하게 스타일리시하게',
    '<h1>여름 의류 컬렉션</h1><p>올 여름, 스타일리시하게! 여름에 어울리는 다양한 의류를 소개합니다.</p><p>후원으로 시원한 여름을 준비하세요!</p><img src="https://example.com/image7.jpg" alt="여름 의류 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>20,000원 후원: 여름 의류 1종</li><li>40,000원 후원: 여름 의류 2종</li><li>70,000원 후원: 여름 의류 4종 + 패션 소품</li></ul>',
    20000, '여름 의류 1종',
    40000, '여름 의류 2종',
    70000, '여름 의류 4종 + 패션 소품',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 8
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    8,
    '문구: 다이어리 컬렉션 - 하루를 기록하다',
    '<h1>다이어리 컬렉션</h1><p>매일매일의 일상을 기록하는 다이어리 컬렉션입니다. 고급스러운 디자인과 다양한 기능으로 무장했습니다.</p><p>후원으로 자신만의 다이어리를 만들어보세요!</p><img src="https://example.com/image8.jpg" alt="다이어리 컬렉션 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>15,000원 후원: 다이어리 1종</li><li>30,000원 후원: 다이어리 2종</li><li>50,000원 후원: 다이어리 3종 + 문구 세트</li></ul>',
    15000, '다이어리 1종',
    30000, '다이어리 2종',
    50000, '다이어리 3종 + 문구 세트',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 9
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    9,
    '반려동물: 맞춤형 사료 패키지 - 우리의 사랑스러운 반려동물을 위한',
    '<h1>맞춤형 사료 패키지</h1><p>우리의 반려동물에게 맞춤형 사료를 제공합니다. 건강을 생각한 최고의 패키지입니다!</p><p>후원으로 반려동물에게 최고의 사료를 주세요!</p><img src="https://example.com/image9.jpg" alt="사료 패키지 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>25,000원 후원: 사료 1봉</li><li>50,000원 후원: 사료 2봉</li><li>80,000원 후원: 사료 4봉 + 반려동물 장난감</li></ul>',
    25000, '사료 1봉',
    50000, '사료 2봉',
    80000, '사료 4봉 + 반려동물 장난감',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 10
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    10,
    '커피: 핸드드립 커피 기기 세트 - 커피 애호가의 필수 아이템',
    '<h1>핸드드립 커피 기기 세트</h1><p>커피 애호가들을 위한 핸드드립 커피 기기 세트입니다. 집에서 완벽한 커피를 즐길 수 있습니다!</p><p>후원으로 최고의 커피 경험을 선사하세요!</p><img src="https://example.com/image10.jpg" alt="핸드드립 기기 세트 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>30,000원 후원: 핸드드립 기기 1종</li><li>60,000원 후원: 핸드드립 기기 1종 + 커피 1봉</li><li>100,000원 후원: 핸드드립 기기 1종 + 커피 3봉 + 세트 추가 기기</li></ul>',
    30000, '핸드드립 기기 1종',
    60000, '핸드드립 기기 1종 + 커피 1봉',
    100000, '핸드드립 기기 1종 + 커피 3봉 + 세트 추가 기기',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 11
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    11,
    '패션: 주얼리 액세서리 - 특별한 날, 특별한 액세서리',
    '<h1>주얼리 액세서리 컬렉션</h1><p>특별한 날, 더욱 특별하게! 주얼리 액세서리 컬렉션입니다. 다양한 디자인으로 당신을 빛나게 합니다.</p><p>후원으로 멋진 액세서리를 손에 넣으세요!</p><img src="https://example.com/image11.jpg" alt="주얼리 액세서리 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>30,000원 후원: 주얼리 1종</li><li>60,000원 후원: 주얼리 2종</li><li>100,000원 후원: 주얼리 4종 + 특별 패키지</li></ul>',
    30000, '주얼리 1종',
    60000, '주얼리 2종',
    100000, '주얼리 4종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 12
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    12,
    '헬스케어: 운동용 보조기구 - 몸의 건강을 지키세요',
    '<h1>운동용 보조기구</h1><p>운동 효과를 높이는 다양한 보조기구를 소개합니다. 건강한 몸을 위한 필수 아이템입니다!</p><p>후원으로 운동에 도움이 되는 보조기구를 받아보세요!</p><img src="https://example.com/image12.jpg" alt="운동용 보조기구 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>20,000원 후원: 보조기구 1종</li><li>40,000원 후원: 보조기구 2종</li><li>70,000원 후원: 보조기구 4종 + 운동 용품 세트</li></ul>',
    20000, '보조기구 1종',
    40000, '보조기구 2종',
    70000, '보조기구 4종 + 운동 용품 세트',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 13
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    13,
    '홈리빙: 인테리어 소품 - 집안을 멋지게 꾸며보세요',
    '<h1>인테리어 소품</h1><p>집안을 더욱 멋지게 꾸밀 수 있는 다양한 인테리어 소품을 소개합니다. 당신의 집에 맞는 소품을 찾아보세요!</p><p>후원으로 특별한 인테리어 소품을 받아보세요!</p><img src="https://example.com/image13.jpg" alt="인테리어 소품 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>15,000원 후원: 인테리어 소품 1종</li><li>30,000원 후원: 인테리어 소품 2종</li><li>50,000원 후원: 인테리어 소품 4종 + 특별 패키지</li></ul>',
    15000, '인테리어 소품 1종',
    30000, '인테리어 소품 2종',
    50000, '인테리어 소품 4종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 14
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    14,
    '패션: 겨울철 필수 의류 - 따뜻하게 겨울을 보내세요',
    '<h1>겨울철 필수 의류</h1><p>겨울철에 필요한 따뜻한 의류를 소개합니다. 스타일리시하면서도 따뜻한 겨울을 보낼 수 있습니다.</p><p>후원으로 겨울 의류를 손쉽게 받아보세요!</p><img src="https://example.com/image14.jpg" alt="겨울철 의류 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>25,000원 후원: 겨울 의류 1종</li><li>50,000원 후원: 겨울 의류 2종</li><li>80,000원 후원: 겨울 의류 4종 + 특별 패키지</li></ul>',
    25000, '겨울 의류 1종',
    50000, '겨울 의류 2종',
    80000, '겨울 의류 4종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 15
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    15,
    '식품: 비건 간식 패키지 - 건강과 맛을 동시에',
    '<h1>비건 간식 패키지</h1><p>맛있고 건강한 비건 간식 패키지입니다. 비건 식사를 즐기는 사람들에게 최적화된 패키지입니다!</p><p>후원으로 건강한 간식을 받아보세요!</p><img src="https://example.com/image15.jpg" alt="비건 간식 패키지 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>20,000원 후원: 비건 간식 1종</li><li>40,000원 후원: 비건 간식 3종</li><li>70,000원 후원: 비건 간식 5종 + 특별 패키지</li></ul>',
    20000, '비건 간식 1종',
    40000, '비건 간식 3종',
    70000, '비건 간식 5종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 16
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    16,
    '디지털미디어: 웹툰 구독 서비스 - 매일 새로운 웹툰을 만나다',
    '<h1>웹툰 구독 서비스</h1><p>매일 새로운 웹툰을 감상할 수 있는 구독 서비스입니다. 다양한 장르의 웹툰을 제공합니다!</p><p>후원으로 웹툰의 세계에 빠져보세요!</p><img src="https://example.com/image16.jpg" alt="웹툰 구독 서비스 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>10,000원 후원: 1개월 웹툰 구독</li><li>20,000원 후원: 3개월 웹툰 구독</li><li>50,000원 후원: 6개월 웹툰 구독 + 특별 콘텐츠</li></ul>',
    10000, '1개월 웹툰 구독',
    20000, '3개월 웹툰 구독',
    50000, '6개월 웹툰 구독 + 특별 콘텐츠',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 17
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    17,
    '가전: 스마트 홈 기기 - 집을 더 스마트하게',
    '<h1>스마트 홈 기기</h1><p>집을 더 스마트하게 만들어주는 다양한 스마트 홈 기기입니다. 최신 기술로 생활을 편리하게!</p><p>후원으로 스마트 홈 기기를 경험하세요!</p><img src="https://example.com/image17.jpg" alt="스마트 홈 기기 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>40,000원 후원: 스마트 홈 기기 1종</li><li>80,000원 후원: 스마트 홈 기기 2종</li><li>150,000원 후원: 스마트 홈 기기 3종 + 스마트 플러그 세트</li></ul>',
    40000, '스마트 홈 기기 1종',
    80000, '스마트 홈 기기 2종',
    150000, '스마트 홈 기기 3종 + 스마트 플러그 세트',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 18
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    18,
    '여행: 글로벌 여행 패키지 - 세계를 탐험하다',
    '<h1>글로벌 여행 패키지</h1><p>전 세계를 탐험할 수 있는 여행 패키지입니다. 다양한 여행지와 특별한 경험을 제공합니다!</p><p>후원으로 꿈의 여행을 현실로 만들어보세요!</p><img src="https://example.com/image18.jpg" alt="글로벌 여행 패키지 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>50,000원 후원: 여행 패키지 1일권</li><li>100,000원 후원: 여행 패키지 3일권</li><li>200,000원 후원: 여행 패키지 7일권 + 특별 투어</li></ul>',
    50000, '여행 패키지 1일권',
    100000, '여행 패키지 3일권',
    200000, '여행 패키지 7일권 + 특별 투어',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 19
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    19,
    '도서: 독서 클럽 가입 - 매월 새로운 책과 만나다',
    '<h1>독서 클럽 가입</h1><p>매월 새로운 책과 만나고, 독서 클럽의 혜택을 누릴 수 있는 구독 서비스입니다.</p><p>후원으로 독서의 즐거움을 만끽하세요!</p><img src="https://example.com/image19.jpg" alt="독서 클럽 가입 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>15,000원 후원: 1개월 독서 클럽 가입</li><li>30,000원 후원: 3개월 독서 클럽 가입</li><li>60,000원 후원: 6개월 독서 클럽 가입 + 특별 도서 세트</li></ul>',
    15000, '1개월 독서 클럽 가입',
    30000, '3개월 독서 클럽 가입',
    60000, '6개월 독서 클럽 가입 + 특별 도서 세트',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 20
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    20,
    '기술: 최신 전자기기 - 혁신을 선도하다',
    '<h1>최신 전자기기</h1><p>가장 최신의 전자기기를 소개합니다. 혁신적인 기술로 새로운 경험을 선사합니다!</p><p>후원으로 최첨단 전자기기를 먼저 경험해보세요!</p><img src="https://example.com/image20.jpg" alt="최신 전자기기 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>50,000원 후원: 전자기기 1종</li><li>100,000원 후원: 전자기기 2종</li><li>200,000원 후원: 전자기기 4종 + 특별 패키지</li></ul>',
    50000, '전자기기 1종',
    100000, '전자기기 2종',
    200000, '전자기기 4종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);
-- 샘플 21
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    21,
    '식품: 전통주 세트 - 고품질 전통주를 경험하다',
    '<h1>전통주 세트</h1><p>한국의 전통주를 모은 특별한 세트입니다. 전통적인 맛과 풍미를 느껴보세요!</p><p>후원으로 전통주의 깊은 맛을 경험하세요!</p><img src="https://example.com/image21.jpg" alt="전통주 세트 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>30,000원 후원: 전통주 1병</li><li>60,000원 후원: 전통주 2병</li><li>100,000원 후원: 전통주 4병 + 특별 패키지</li></ul>',
    30000, '전통주 1병',
    60000, '전통주 2병',
    100000, '전통주 4병 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 22
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    22,
    '반려동물: 애완용 장난감 - 반려동물과의 즐거운 시간',
    '<h1>애완용 장난감</h1><p>반려동물을 위한 다양한 장난감을 소개합니다. 함께 놀고 즐길 수 있는 아이템들입니다!</p><p>후원으로 반려동물에게 즐거움을 선사하세요!</p><img src="https://example.com/image22.jpg" alt="애완용 장난감 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>15,000원 후원: 장난감 1종</li><li>30,000원 후원: 장난감 3종</li><li>50,000원 후원: 장난감 5종 + 특별 패키지</li></ul>',
    15000, '장난감 1종',
    30000, '장난감 3종',
    50000, '장난감 5종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 23
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    23,
    '패션: 특별한 신발 컬렉션 - 스타일을 완성하다',
    '<h1>신발 컬렉션</h1><p>특별한 디자인의 신발 컬렉션입니다. 스타일과 편안함을 동시에 제공합니다!</p><p>후원으로 멋진 신발을 소유하세요!</p><img src="https://example.com/image23.jpg" alt="신발 컬렉션 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>40,000원 후원: 신발 1종</li><li>80,000원 후원: 신발 2종</li><li>150,000원 후원: 신발 4종 + 특별 패키지</li></ul>',
    40000, '신발 1종',
    80000, '신발 2종',
    150000, '신발 4종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 24
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    24,
    '헬스케어: 영양제 세트 - 건강을 지키는 비결',
    '<h1>영양제 세트</h1><p>건강을 위한 필수 영양제를 모은 세트입니다. 건강한 라이프스타일을 유지하세요!</p><p>후원으로 건강한 몸을 만드세요!</p><img src="https://example.com/image24.jpg" alt="영양제 세트 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>20,000원 후원: 영양제 1종</li><li>40,000원 후원: 영양제 3종</li><li>70,000원 후원: 영양제 6종 + 건강 식품 세트</li></ul>',
    20000, '영양제 1종',
    40000, '영양제 3종',
    70000, '영양제 6종 + 건강 식품 세트',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 25
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    25,
    '디지털미디어: 음악 앨범 - 감동의 멜로디',
    '<h1>음악 앨범</h1><p>최신 음악 앨범을 소개합니다. 다양한 장르의 음악을 감상하세요!</p><p>후원으로 감동의 멜로디를 경험하세요!</p><img src="https://example.com/image25.jpg" alt="음악 앨범 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>15,000원 후원: 음악 앨범 1장</li><li>30,000원 후원: 음악 앨범 3장</li><li>60,000원 후원: 음악 앨범 6장 + 특별 콘텐츠</li></ul>',
    15000, '음악 앨범 1장',
    30000, '음악 앨범 3장',
    60000, '음악 앨범 6장 + 특별 콘텐츠',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 26
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    26,
    '홈리빙: 욕실용품 세트 - 편안한 욕실 경험',
    '<h1>욕실용품 세트</h1><p>편안한 욕실 환경을 위한 다양한 욕실용품을 소개합니다. 사용하기 편리한 아이템들입니다!</p><p>후원으로 편안한 욕실을 만들어보세요!</p><img src="https://example.com/image26.jpg" alt="욕실용품 세트 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>20,000원 후원: 욕실용품 1종</li><li>40,000원 후원: 욕실용품 3종</li><li>70,000원 후원: 욕실용품 5종 + 특별 패키지</li></ul>',
    20000, '욕실용품 1종',
    40000, '욕실용품 3종',
    70000, '욕실용품 5종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 27
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    27,
    '문구: 특별한 다이어리 - 계획을 정리하다',
    '<h1>특별한 다이어리</h1><p>올해의 계획을 정리할 수 있는 특별한 다이어리입니다. 다양한 디자인과 기능을 제공합니다!</p><p>후원으로 자신의 계획을 정리하세요!</p><img src="https://example.com/image27.jpg" alt="특별한 다이어리 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>10,000원 후원: 다이어리 1권</li><li>20,000원 후원: 다이어리 2권</li><li>40,000원 후원: 다이어리 5권 + 특별 패키지</li></ul>',
    10000, '다이어리 1권',
    20000, '다이어리 2권',
    40000, '다이어리 5권 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 28
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    28,
    '커피: 프리미엄 원두 - 커피의 진수를 경험하다',
    '<h1>프리미엄 원두</h1><p>세계 각국의 프리미엄 원두를 소개합니다. 다양한 맛을 즐길 수 있는 원두입니다!</p><p>후원으로 최고의 커피를 경험하세요!</p><img src="https://example.com/image28.jpg" alt="프리미엄 원두 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>25,000원 후원: 원두 250g</li><li>50,000원 후원: 원두 500g</li><li>90,000원 후원: 원두 1kg + 특별 패키지</li></ul>',
    25000, '원두 250g',
    50000, '원두 500g',
    90000, '원두 1kg + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 29
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    29,
    '향초: 아로마 캔들 - 집에서의 힐링 타임',
    '<h1>아로마 캔들</h1><p>집에서 편안함을 제공하는 아로마 캔들입니다. 다양한 향으로 힐링의 시간을 제공합니다!</p><p>후원으로 집에서의 힐링을 경험하세요!</p><img src="https://example.com/image29.jpg" alt="아로마 캔들 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>20,000원 후원: 아로마 캔들 1종</li><li>40,000원 후원: 아로마 캔들 3종</li><li>70,000원 후원: 아로마 캔들 5종 + 특별 패키지</li></ul>',
    20000, '아로마 캔들 1종',
    40000, '아로마 캔들 3종',
    70000, '아로마 캔들 5종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 30
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    30,
    '디지털미디어: 웹툰 패키지 - 재미와 감동을 더하다',
    '<h1>웹툰 패키지</h1><p>다양한 장르의 웹툰 패키지입니다. 재미있고 감동적인 이야기들을 제공합니다!</p><p>후원으로 웹툰의 매력을 느껴보세요!</p><img src="https://example.com/image30.jpg" alt="웹툰 패키지 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>10,000원 후원: 웹툰 1개월 구독권</li><li>20,000원 후원: 웹툰 3개월 구독권</li><li>40,000원 후원: 웹툰 6개월 구독권 + 특별 콘텐츠</li></ul>',
    10000, '웹툰 1개월 구독권',
    20000, '웹툰 3개월 구독권',
    40000, '웹툰 6개월 구독권 + 특별 콘텐츠',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 31
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    31,
    '커피: 프리미엄 커피 머신 - 완벽한 커피를 위해',
    '<h1>프리미엄 커피 머신</h1><p>최고의 커피 머신을 소개합니다. 집에서 전문 바리스타처럼 커피를 즐기세요!</p><p>후원으로 최고의 커피를 경험하세요!</p><img src="https://example.com/image31.jpg" alt="커피 머신 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>100,000원 후원: 커피 머신 1대</li><li>200,000원 후원: 커피 머신 1대 + 원두 500g</li><li>300,000원 후원: 커피 머신 1대 + 원두 1kg + 특별 패키지</li></ul>',
    100000, '커피 머신 1대',
    200000, '커피 머신 1대 + 원두 500g',
    300000, '커피 머신 1대 + 원두 1kg + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 32
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    32,
    '헬스케어: 운동 보조기구 - 건강한 라이프스타일',
    '<h1>운동 보조기구</h1><p>운동 효과를 극대화할 수 있는 보조기구입니다. 건강한 몸을 위한 필수 아이템입니다!</p><p>후원으로 건강한 라이프스타일을 만들어보세요!</p><img src="https://example.com/image32.jpg" alt="운동 보조기구 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>25,000원 후원: 운동 보조기구 1종</li><li>50,000원 후원: 운동 보조기구 2종</li><li>80,000원 후원: 운동 보조기구 4종 + 특별 패키지</li></ul>',
    25000, '운동 보조기구 1종',
    50000, '운동 보조기구 2종',
    80000, '운동 보조기구 4종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 33
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    33,
    '식품: 비건 간식 - 건강한 간식으로 가득한 하루',
    '<h1>비건 간식</h1><p>비건을 위한 맛있고 건강한 간식을 소개합니다. 매일 간편하게 즐기세요!</p><p>후원으로 건강한 간식을 경험하세요!</p><img src="https://example.com/image33.jpg" alt="비건 간식 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>10,000원 후원: 비건 간식 1팩</li><li>20,000원 후원: 비건 간식 3팩</li><li>35,000원 후원: 비건 간식 6팩 + 특별 패키지</li></ul>',
    10000, '비건 간식 1팩',
    20000, '비건 간식 3팩',
    35000, '비건 간식 6팩 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 34
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    34,
    '패션: 주얼리 컬렉션 - 우아함을 더하다',
    '<h1>주얼리 컬렉션</h1><p>우아하고 세련된 주얼리 컬렉션입니다. 특별한 날을 위한 완벽한 액세서리입니다!</p><p>후원으로 특별한 주얼리를 소유하세요!</p><img src="https://example.com/image34.jpg" alt="주얼리 컬렉션 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>50,000원 후원: 주얼리 1종</li><li>100,000원 후원: 주얼리 2종</li><li>200,000원 후원: 주얼리 4종 + 특별 패키지</li></ul>',
    50000, '주얼리 1종',
    100000, '주얼리 2종',
    200000, '주얼리 4종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 35
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    35,
    '홈리빙: 인테리어 소품 - 집 안의 변화를 주다',
    '<h1>인테리어 소품</h1><p>집안을 꾸밀 수 있는 다양한 인테리어 소품입니다. 새롭게 변화된 집안을 만드세요!</p><p>후원으로 집안을 꾸며보세요!</p><img src="https://example.com/image35.jpg" alt="인테리어 소품 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>15,000원 후원: 인테리어 소품 1종</li><li>30,000원 후원: 인테리어 소품 3종</li><li>50,000원 후원: 인테리어 소품 5종 + 특별 패키지</li></ul>',
    15000, '인테리어 소품 1종',
    30000, '인테리어 소품 3종',
    50000, '인테리어 소품 5종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 36
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    36,
    '식품: 와인 세트 - 특별한 저녁을 위한 선택',
    '<h1>와인 세트</h1><p>특별한 저녁을 위한 프리미엄 와인 세트입니다. 다양한 와인으로 특별한 시간을 만들어보세요!</p><p>후원으로 특별한 와인을 경험하세요!</p><img src="https://example.com/image36.jpg" alt="와인 세트 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>50,000원 후원: 와인 1병</li><li>100,000원 후원: 와인 2병</li><li>200,000원 후원: 와인 4병 + 특별 패키지</li></ul>',
    50000, '와인 1병',
    100000, '와인 2병',
    200000, '와인 4병 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 37
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    37,
    '디지털미디어: 도서 패키지 - 지식의 세계로',
    '<h1>도서 패키지</h1><p>지식을 확장할 수 있는 도서 패키지입니다. 다양한 분야의 책을 제공합니다!</p><p>후원으로 지식의 세계를 탐험하세요!</p><img src="https://example.com/image37.jpg" alt="도서 패키지 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>20,000원 후원: 도서 1권</li><li>40,000원 후원: 도서 3권</li><li>70,000원 후원: 도서 6권 + 특별 패키지</li></ul>',
    20000, '도서 1권',
    40000, '도서 3권',
    70000, '도서 6권 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 38
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    38,
    '패션: 여름 의류 - 시원하게 여름을 즐기다',
    '<h1>여름 의류</h1><p>시원하고 편안한 여름 의류입니다. 여름철 시원하게 입을 수 있는 의류를 제공합니다!</p><p>후원으로 여름을 시원하게 즐기세요!</p><img src="https://example.com/image38.jpg" alt="여름 의류 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>30,000원 후원: 여름 의류 1종</li><li>60,000원 후원: 여름 의류 2종</li><li>100,000원 후원: 여름 의류 4종 + 특별 패키지</li></ul>',
    30000, '여름 의류 1종',
    60000, '여름 의류 2종',
    100000, '여름 의류 4종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 39
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    39,
    '헬스케어: 헬스 기구 - 건강과 운동의 동반자',
    '<h1>헬스 기구</h1><p>건강과 운동을 위한 필수 헬스 기구입니다. 체력을 기르고 건강한 몸을 유지하세요!</p><p>후원으로 헬스 기구를 소유하세요!</p><img src="https://example.com/image39.jpg" alt="헬스 기구 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>40,000원 후원: 헬스 기구 1종</li><li>80,000원 후원: 헬스 기구 2종</li><li>120,000원 후원: 헬스 기구 4종 + 특별 패키지</li></ul>',
    40000, '헬스 기구 1종',
    80000, '헬스 기구 2종',
    120000, '헬스 기구 4종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 40
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    40,
    '디지털미디어: 음악 스트리밍 서비스 - 음악의 세계를 열다',
    '<h1>음악 스트리밍 서비스</h1><p>다양한 음악을 즐길 수 있는 스트리밍 서비스입니다. 감동적인 음악을 경험하세요!</p><p>후원으로 음악의 세계를 탐험하세요!</p><img src="https://example.com/image40.jpg" alt="음악 스트리밍 서비스 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>15,000원 후원: 1개월 구독권</li><li>30,000원 후원: 3개월 구독권</li><li>50,000원 후원: 6개월 구독권 + 특별 콘텐츠</li></ul>',
    15000, '1개월 구독권',
    30000, '3개월 구독권',
    50000, '6개월 구독권 + 특별 콘텐츠',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 41
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    41,
    '패션: 가방 컬렉션 - 스타일을 완성하다',
    '<h1>가방 컬렉션</h1><p>세련된 가방 컬렉션입니다. 어떤 스타일에도 어울리는 완벽한 가방들!</p><p>후원으로 스타일을 완성하세요!</p><img src="https://example.com/image41.jpg" alt="가방 컬렉션 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>70,000원 후원: 가방 1종</li><li>140,000원 후원: 가방 2종</li><li>250,000원 후원: 가방 4종 + 특별 패키지</li></ul>',
    70000, '가방 1종',
    140000, '가방 2종',
    250000, '가방 4종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 42
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    42,
    '홈리빙: 주방 가전 - 요리를 쉽게',
    '<h1>주방 가전</h1><p>요리를 보다 쉽게 만들어주는 다양한 주방 가전입니다. 집에서 전문가처럼 요리하세요!</p><p>후원으로 주방을 업그레이드하세요!</p><img src="https://example.com/image42.jpg" alt="주방 가전 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>60,000원 후원: 주방 가전 1종</li><li>120,000원 후원: 주방 가전 2종</li><li>200,000원 후원: 주방 가전 4종 + 특별 패키지</li></ul>',
    60000, '주방 가전 1종',
    120000, '주방 가전 2종',
    200000, '주방 가전 4종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 43
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    43,
    '디지털미디어: 웹툰 구독권 - 다양한 웹툰을 만나다',
    '<h1>웹툰 구독권</h1><p>다양한 웹툰을 구독할 수 있는 기회입니다. 새로운 웹툰을 매일 즐기세요!</p><p>후원으로 웹툰의 세계를 탐험하세요!</p><img src="https://example.com/image43.jpg" alt="웹툰 구독권 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>20,000원 후원: 1개월 구독권</li><li>40,000원 후원: 3개월 구독권</li><li>70,000원 후원: 6개월 구독권 + 특별 콘텐츠</li></ul>',
    20000, '1개월 구독권',
    40000, '3개월 구독권',
    70000, '6개월 구독권 + 특별 콘텐츠',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 44
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    44,
    '헬스케어: 영양제 - 건강을 챙기다',
    '<h1>영양제</h1><p>건강을 유지할 수 있는 영양제입니다. 매일 섭취하여 건강한 생활을 유지하세요!</p><p>후원으로 건강을 챙기세요!</p><img src="https://example.com/image44.jpg" alt="영양제 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>30,000원 후원: 영양제 1병</li><li>60,000원 후원: 영양제 2병</li><li>100,000원 후원: 영양제 4병 + 특별 패키지</li></ul>',
    30000, '영양제 1병',
    60000, '영양제 2병',
    100000, '영양제 4병 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 45
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    45,
    '식품: 전통주 세트 - 한국의 맛을 경험하다',
    '<h1>전통주 세트</h1><p>한국 전통주의 다양한 맛을 즐길 수 있는 세트입니다. 전통의 맛을 느껴보세요!</p><p>후원으로 한국의 전통주를 경험하세요!</p><img src="https://example.com/image45.jpg" alt="전통주 세트 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>40,000원 후원: 전통주 1병</li><li>80,000원 후원: 전통주 2병</li><li>150,000원 후원: 전통주 4병 + 특별 패키지</li></ul>',
    40000, '전통주 1병',
    80000, '전통주 2병',
    150000, '전통주 4병 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 46
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    46,
    '패션: 신발 컬렉션 - 스타일을 완성하다',
    '<h1>신발 컬렉션</h1><p>다양한 스타일의 신발 컬렉션입니다. 모든 상황에 어울리는 신발을 제공합니다!</p><p>후원으로 신발 컬렉션을 완성하세요!</p><img src="https://example.com/image46.jpg" alt="신발 컬렉션 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>60,000원 후원: 신발 1종</li><li>120,000원 후원: 신발 2종</li><li>200,000원 후원: 신발 4종 + 특별 패키지</li></ul>',
    60000, '신발 1종',
    120000, '신발 2종',
    200000, '신발 4종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 47
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    47,
    '문구: 다이어리 - 일상을 기록하다',
    '<h1>다이어리</h1><p>매일의 계획과 일상을 기록할 수 있는 다이어리입니다. 잘 정리된 일상이 당신의 미래를 만듭니다!</p><p>후원으로 일상을 기록하세요!</p><img src="https://example.com/image47.jpg" alt="다이어리 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>20,000원 후원: 다이어리 1권</li><li>40,000원 후원: 다이어리 2권</li><li>70,000원 후원: 다이어리 4권 + 특별 패키지</li></ul>',
    20000, '다이어리 1권',
    40000, '다이어리 2권',
    70000, '다이어리 4권 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 48
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    48,
    '커피: 드립커피 - 집에서 즐기는 바리스타의 맛',
    '<h1>드립커피</h1><p>전문 바리스타가 추천하는 드립커피입니다. 집에서도 바리스타의 맛을 경험하세요!</p><p>후원으로 커피의 진정한 맛을 느껴보세요!</p><img src="https://example.com/image48.jpg" alt="드립커피 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>30,000원 후원: 드립커피 1종</li><li>60,000원 후원: 드립커피 2종</li><li>100,000원 후원: 드립커피 4종 + 특별 패키지</li></ul>',
    30000, '드립커피 1종',
    60000, '드립커피 2종',
    100000, '드립커피 4종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 49
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    49,
    '반려동물: 놀이기구 - 재미있는 시간',
    '<h1>놀이기구</h1><p>반려동물을 위한 다양한 놀이기구입니다. 귀여운 반려동물에게 재미있는 시간을 선사하세요!</p><p>후원으로 반려동물의 시간을 즐겁게 하세요!</p><img src="https://example.com/image49.jpg" alt="놀이기구 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>30,000원 후원: 놀이기구 1종</li><li>60,000원 후원: 놀이기구 2종</li><li>100,000원 후원: 놀이기구 4종 + 특별 패키지</li></ul>',
    30000, '놀이기구 1종',
    60000, '놀이기구 2종',
    100000, '놀이기구 4종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);

-- 샘플 50
INSERT INTO article (
    atc_id, atc_title, atc_body,
    atc_reward_balance_1, atc_reward_item_1,
    atc_reward_balance_2, atc_reward_item_2,
    atc_reward_balance_3, atc_reward_item_3,
    atc_reward_balance_4, atc_reward_item_4,
    atc_reward_balance_5, atc_reward_item_5,
    atc_reward_balance_6, atc_reward_item_6
) VALUES (
    50,
    '향초: 디퓨저 - 집안을 향기롭게',
    '<h1>디퓨저</h1><p>집안을 향기롭게 만들어주는 디퓨저입니다. 편안한 분위기를 만들어보세요!</p><p>후원으로 집안의 분위기를 향기롭게!</p><img src="https://example.com/image50.jpg" alt="디퓨저 이미지"/><hr/><p><b>보상 내용:</b></p><ul><li>25,000원 후원: 디퓨저 1종</li><li>50,000원 후원: 디퓨저 2종</li><li>85,000원 후원: 디퓨저 4종 + 특별 패키지</li></ul>',
    25000, '디퓨저 1종',
    50000, '디퓨저 2종',
    85000, '디퓨저 4종 + 특별 패키지',
    NULL, NULL,
    NULL, NULL,
    NULL, NULL
);