DROP TABLE projects;

DROP SEQUENCE project_seq;

-- 사용자 테이블
CREATE TABLE funfun_user (
    usr_email       VARCHAR2(255) PRIMARY KEY,  -- 아이디 = 이메일 주소
    usr_password    VARCHAR2(255) NOT NULL,     -- 비밀번호
    usr_birth       CHAR(8) NOT NULL,           -- 주민번호 앞자리 (형식 YYYYMMDD)
    usr_name        VARCHAR2(100) NOT NULL,     -- 사용자 실명
    usr_phone       VARCHAR2(13) NOT NULL,      -- 전화번호, 010NNNNNNNN 형식
    usr_gender      CHAR(1) NOT NULL,           -- 성별은 주민등록번호 뒷자리에서 결정 (1자)
    usr_nickname    VARCHAR2(50) NOT NULL,      -- 닉네임
    usr_authlevel   NUMBER(1) NOT NULL          -- 사용자 권한 레벨 (0. 후원자, 1. 창작자, 2. 관리자)
);

-- 펀딩 프로젝트 테이블
CREATE TABLE projects (
    prj_id NUMBER PRIMARY KEY, -- 게시글 id
    prj_name VARCHAR2(255 CHAR), -- 상품명
    prj_fun NUMBER(3,1), -- 게시글 FUN (평점)
    prj_likes NUMBER, -- 게시글 좋아요
    prj_goal NUMBER, -- 목표 그램
    prj_current NUMBER, -- 현재 모금액 
    prj_author VARCHAR2(255 CHAR), -- 게시글 작성자 (user 테이블과 공유할건지 고민)
    prj_maincate VARCHAR2(100 CHAR), -- 주 카테고리
    prj_subcate VARCHAR2(100 CHAR), -- 보조 카테고리
    prj_upload TIMESTAMP, -- 게시글 업로드 날짜
    prj_update TIMESTAMP, -- 게시글 수정 날짜
    prj_expiration TIMESTAMP, -- 펀딩 종료 날짜
    prj_premium NUMBER(1) -- 광고 등록 여부
);

-- 펀딩 게시글 내용 테이블
CREATE TABLE article (
    atc_id NUMBER PRIMARY KEY,
    atc_title VARCHAR2(4000 CHAR), -- 게시글 제목
    atc_body CLOB, -- 게시글 내용
    atc_reward_balance_1 NUMBER, -- 후원 금액 1번째 항목
    atc_reward_item_1 VARCHAR2(255 CHAR), -- 금액에 대한 보상 내용 1번째 항목
    atc_reward_balance_2 NUMBER,
    atc_reward_item_2 VARCHAR2(255 CHAR),
    atc_reward_balance_3 NUMBER,
    atc_reward_item_3 VARCHAR2(255 CHAR),
    atc_reward_balance_4 NUMBER,
    atc_reward_item_4 VARCHAR2(255 CHAR),
    atc_reward_balance_5 NUMBER,
    atc_reward_item_5 VARCHAR2(255 CHAR),
    atc_reward_balance_6 NUMBER,
    atc_reward_item_6 VARCHAR2(255 CHAR)
);

-- 외래키 제약 조건 추가: 유저 아이디와 프로젝트 제작자
ALTER TABLE projects
	ADD CONSTRAINT fk_author FOREIGN KEY (prj_author) REFERENCES funfun_user (usr_email);

-- 외래키 제약 조건 추가: 게시글 정보 id와 프로젝트 id
ALTER TABLE article
	ADD CONSTRAINT fk_article_project FOREIGN KEY (atc_id) REFERENCES projects (prj_id);

-- 게시글 중복되지 않도록 시퀸스로 아이디 정하기
CREATE SEQUENCE project_seq START WITH 1 INCREMENT BY 1 MAXVALUE 999999 CYCLE NOCACHE;

-- 프로젝트 테이블에 id를 자동으로 설정하는 트리거
CREATE OR REPLACE TRIGGER trg_before_insert_projects
BEFORE INSERT ON projects
FOR EACH ROW
BEGIN
    IF :NEW.prj_id IS NULL THEN
        SELECT project_seq.NEXTVAL INTO :NEW.prj_id FROM dual;
    END IF;
END;
/
