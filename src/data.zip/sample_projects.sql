-- 테스트 계정
INSERT INTO funfun_user (usr_email, usr_password, usr_birth, usr_name, usr_phone, usr_gender, usr_nickname, usr_authlevel)
VALUES
('project_author@funfun.kinari.ink', 'hashed_password', '19800101', '테스트 사용자', '01012345678', 'M', '프로젝트작성자', 1);

-- 50개의 샘플 데이터 삽입
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(1, '프리미엄 헬스케어 보충제', 4.5, 2100, 3000000, 3500000, 'project_author@funfun.kinari.ink', '헬스케어', '보충제', TO_TIMESTAMP('2024-01-10 07:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-01-10 08:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-03-10 07:15:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(2, '고품질 커피 원두', 4.8, 3200, 5000000, 6000000, 'project_author@funfun.kinari.ink', '커피', '원두', TO_TIMESTAMP('2024-01-15 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-01-15 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-03-15 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(3, '최고급 향초 세트', 4.2, 1800, 2000000, 2200000, 'project_author@funfun.kinari.ink', '향초', '캔들', TO_TIMESTAMP('2024-02-01 10:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-02-01 11:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-04-01 10:30:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(4, '반려동물 맞춤형 장난감', 3.9, 1500, 1500000, 1800000, 'project_author@funfun.kinari.ink', '반려동물', '놀이기구', TO_TIMESTAMP('2024-02-10 11:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-02-10 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-04-10 11:00:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(5, '홈리빙 인테리어 소품', 4.0, 2100, 2000000, 2300000, 'project_author@funfun.kinari.ink', '홈리빙', '인테리어', TO_TIMESTAMP('2024-03-01 08:45:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-03-01 09:45:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 08:45:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(6, '디지털미디어 독점 콘텐츠', 4.7, 2900, 3500000, 4000000, 'project_author@funfun.kinari.ink', '디지털미디어', '웹툰', TO_TIMESTAMP('2024-03-10 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-03-10 13:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-10 12:00:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(7, '스포츠 웨어 최신 컬렉션', 4.3, 2000, 4000000, 4200000, 'project_author@funfun.kinari.ink', '헬스케어', '스포츠 웨어', TO_TIMESTAMP('2024-04-01 07:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-04-01 08:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-06-01 07:30:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(8, '예술가의 클래식 디자인', 4.6, 2300, 2500000, 2600000, 'project_author@funfun.kinari.ink', '패션', '주얼리', TO_TIMESTAMP('2024-04-10 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-04-10 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-06-10 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(9, '프리미엄 커피 머신', 4.4, 1900, 8000000, 8500000, 'project_author@funfun.kinari.ink', '커피', '머신', TO_TIMESTAMP('2024-05-01 10:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 11:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-07-01 10:30:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(10, '한정판 와인 컬렉션', 4.9, 3100, 10000000, 10500000, 'project_author@funfun.kinari.ink', '식품', '와인', TO_TIMESTAMP('2024-05-10 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-10 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-07-10 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(11, '고양이용 프리미엄 사료', 4.1, 1700, 1800000, 1900000, 'project_author@funfun.kinari.ink', '반려동물', '사료', TO_TIMESTAMP('2024-06-01 07:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-06-01 08:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-08-01 07:15:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(12, '건강한 스낵 패키지', 4.2, 1850, 1500000, 1600000, 'project_author@funfun.kinari.ink', '식품', '간식', TO_TIMESTAMP('2024-06-10 09:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-06-10 10:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-08-10 09:30:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(13, '캔들워머 세트', 4.4, 2200, 2500000, 2700000, 'project_author@funfun.kinari.ink', '향초', '캔들워머', TO_TIMESTAMP('2024-06-15 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-06-15 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-08-15 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(14, '고급 패션 액세서리', 4.3, 2100, 4000000, 4200000, 'project_author@funfun.kinari.ink', '패션', '패션소품', TO_TIMESTAMP('2024-07-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-07-01 11:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-09-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(15, '고급 향수/공병 세트', 4.6, 2400, 3500000, 3600000, 'project_author@funfun.kinari.ink', '향초', '향수/공병', TO_TIMESTAMP('2024-07-10 11:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-07-10 12:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-09-10 11:15:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(16, '다양한 디자인의 캘린더', 4.1, 1800, 1200000, 1300000, 'project_author@funfun.kinari.ink', '문구', '캘린더', TO_TIMESTAMP('2024-08-01 09:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-08-01 10:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-10-01 09:30:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(17, 'DIY 인테리어 소품', 4.2, 1900, 2500000, 2600000, 'project_author@funfun.kinari.ink', '홈리빙', 'DIY', TO_TIMESTAMP('2024-08-10 08:45:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-08-10 09:45:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-10-10 08:45:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(18, '프리미엄 비건 식품 패키지', 4.7, 2300, 3500000, 3700000, 'project_author@funfun.kinari.ink', '식품', '비건', TO_TIMESTAMP('2024-09-01 07:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-09-01 08:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-11-01 07:30:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(19, '컬러풀 패션 의류', 4.4, 2000, 3000000, 3200000, 'project_author@funfun.kinari.ink', '패션', '의류', TO_TIMESTAMP('2024-09-10 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-09-10 11:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-11-10 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(20, '완벽한 콜드브루', 4.5, 2100, 4000000, 4200000, 'project_author@funfun.kinari.ink', '커피', '콜드브루', TO_TIMESTAMP('2024-10-01 09:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-10-01 10:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-12-01 09:15:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(21, '정통 전통주', 4.0, 2500, 6000000, 6200000, 'project_author@funfun.kinari.ink', '식품', '전통주', TO_TIMESTAMP('2024-10-10 08:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-10-10 09:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-12-10 08:30:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(22, '스마트 디지털 기기', 4.6, 2400, 5000000, 5200000, 'project_author@funfun.kinari.ink', '디지털미디어', '게임', TO_TIMESTAMP('2024-11-01 07:45:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-11-01 08:45:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-01-01 07:45:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(23, '클래식 음악 앨범', 4.7, 2300, 2500000, 2700000, 'project_author@funfun.kinari.ink', '디지털미디어', '음악', TO_TIMESTAMP('2024-11-10 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-11-10 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-01-10 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(24, '고양이 전용 관리용품', 4.3, 2000, 1500000, 1600000, 'project_author@funfun.kinari.ink', '반려동물', '관리용품', TO_TIMESTAMP('2024-12-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-12-01 11:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-02-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(25, '스마트 헬스 기구', 4.8, 2900, 7000000, 7300000, 'project_author@funfun.kinari.ink', '헬스케어', '헬스 기구', TO_TIMESTAMP('2024-12-10 09:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-12-10 10:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-02-10 09:15:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(26, '아트 작품 컬렉션', 4.4, 2200, 3000000, 3200000, 'project_author@funfun.kinari.ink', '디지털미디어', '아트', TO_TIMESTAMP('2024-12-15 08:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-12-15 09:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-02-15 08:30:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(27, '고품질 비건 음료', 4.5, 2300, 4000000, 4100000, 'project_author@funfun.kinari.ink', '식품', '음료', TO_TIMESTAMP('2025-01-01 07:45:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-01-01 08:45:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-03-01 07:45:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(28, '고급 패션 가방', 4.2, 2000, 5000000, 5200000, 'project_author@funfun.kinari.ink', '패션', '가방', TO_TIMESTAMP('2025-01-10 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-01-10 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-03-10 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(29, '프리미엄 건강식품', 4.6, 2400, 3000000, 3200000, 'project_author@funfun.kinari.ink', '헬스케어', '건강식품', TO_TIMESTAMP('2025-01-15 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-01-15 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-03-15 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(30, '프리미엄 디카페인 커피', 4.3, 2100, 3500000, 3600000, 'project_author@funfun.kinari.ink', '커피', '디카페인', TO_TIMESTAMP('2025-02-01 09:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-02-01 10:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-04-01 09:15:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(31, '아트 도서', 4.4, 2200, 2000000, 2100000, 'project_author@funfun.kinari.ink', '디지털미디어', '도서', TO_TIMESTAMP('2025-02-10 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-02-10 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-04-10 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(32, '예술가의 핸드메이드 신발', 4.5, 2500, 4500000, 4700000, 'project_author@funfun.kinari.ink', '패션', '신발', TO_TIMESTAMP('2025-03-01 09:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-03-01 10:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-05-01 09:30:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(33, '고양이 전용 의류', 4.0, 1900, 1200000, 1300000, 'project_author@funfun.kinari.ink', '반려동물', '의류', TO_TIMESTAMP('2025-03-10 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-03-10 11:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-05-10 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(34, '미니멀 홈리빙 소품', 4.6, 2400, 2500000, 2600000, 'project_author@funfun.kinari.ink', '홈리빙', '화훼/원예', TO_TIMESTAMP('2025-03-15 07:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-03-15 08:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-05-15 07:15:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(35, '디지털 예술 작품', 4.7, 2500, 3000000, 3200000, 'project_author@funfun.kinari.ink', '디지털미디어', '아트', TO_TIMESTAMP('2025-04-01 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-04-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-06-01 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(36, '시즌 한정 주얼리', 4.4, 2200, 4000000, 4200000, 'project_author@funfun.kinari.ink', '패션', '주얼리', TO_TIMESTAMP('2025-04-10 09:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-04-10 10:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-06-10 09:30:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(37, '핸드메이드 향초', 4.6, 2300, 3000000, 3100000, 'project_author@funfun.kinari.ink', '향초', '캔들', TO_TIMESTAMP('2025-05-01 07:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-05-01 08:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-07-01 07:30:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(38, '최신형 커피 캡슐', 4.5, 2400, 5000000, 5200000, 'project_author@funfun.kinari.ink', '커피', '캡슐', TO_TIMESTAMP('2025-05-10 08:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-05-10 09:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-07-10 08:15:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(39, '프리미엄 스티커 컬렉션', 4.3, 2100, 1500000, 1600000, 'project_author@funfun.kinari.ink', '문구', '스티커', TO_TIMESTAMP('2025-06-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-06-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-08-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(40, '향초와 방향제 세트', 4.4, 2200, 2000000, 2100000, 'project_author@funfun.kinari.ink', '향초', '방향제', TO_TIMESTAMP('2025-06-10 10:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-06-10 11:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-08-10 10:30:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(41, '클래식한 원두 커피', 4.5, 2200, 3000000, 3200000, 'project_author@funfun.kinari.ink', '커피', '원두', TO_TIMESTAMP('2025-07-01 07:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-07-01 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-09-01 07:00:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(42, '고급 요리책 세트', 4.6, 2400, 1500000, 1600000, 'project_author@funfun.kinari.ink', '식품', '요리책', TO_TIMESTAMP('2025-07-10 08:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-07-10 09:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-09-10 08:30:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(43, '주말 전통주 패키지', 4.4, 2000, 3000000, 3200000, 'project_author@funfun.kinari.ink', '식품', '전통주', TO_TIMESTAMP('2025-08-01 09:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-08-01 10:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-10-01 09:30:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(44, '프리미엄 고양이 모래', 4.1, 1700, 2000000, 2100000, 'project_author@funfun.kinari.ink', '반려동물', '고양이 모래', TO_TIMESTAMP('2025-08-10 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-08-10 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-10-10 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(45, '스마트 홈 기기', 4.6, 2500, 4000000, 4200000, 'project_author@funfun.kinari.ink', '디지털미디어', '스마트홈', TO_TIMESTAMP('2025-09-01 09:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-09-01 10:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-11-01 09:15:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(46, '예술적 디자인 포스터', 4.5, 2200, 1500000, 1600000, 'project_author@funfun.kinari.ink', '디지털미디어', '아트', TO_TIMESTAMP('2025-09-10 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-09-10 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-11-10 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(47, '프리미엄 바디로션', 4.4, 2100, 2000000, 2100000, 'project_author@funfun.kinari.ink', '뷰티', '로션', TO_TIMESTAMP('2025-10-01 08:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-10-01 09:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-12-01 08:30:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(48, '건강한 반려동물 간식', 4.6, 2000, 1800000, 1900000, 'project_author@funfun.kinari.ink', '반려동물', '간식', TO_TIMESTAMP('2025-10-10 09:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-10-10 10:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-12-10 09:15:00', 'YYYY-MM-DD HH24:MI:SS'), 1);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(49, '프리미엄 전자책', 4.7, 2200, 1200000, 1300000, 'project_author@funfun.kinari.ink', '디지털미디어', '전자책', TO_TIMESTAMP('2025-11-01 07:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-11-01 08:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2026-01-01 07:30:00', 'YYYY-MM-DD HH24:MI:SS'), 0);
INSERT INTO projects (
    prj_id, prj_name, prj_fun, prj_likes, prj_goal, prj_current, prj_author, 
    prj_maincate, prj_subcate, prj_upload, prj_update, prj_expiration, prj_premium
) VALUES
(50, '디지털 포토북', 4.5, 2000, 1500000, 1600000, 'project_author@funfun.kinari.ink', '디지털미디어', '포토북', TO_TIMESTAMP('2025-11-10 08:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2025-11-10 09:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2026-01-10 08:15:00', 'YYYY-MM-DD HH24:MI:SS'), 0);